<div class="copyrights">
	 <p>ICS. All Rights Reserved |  <a href="#">ICS</a> </p>
</div>	
